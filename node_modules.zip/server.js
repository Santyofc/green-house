const express = require('express');
const cors = require('cors');
const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  'https://zyaggofypjrvbexlkgkd.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inp5YWdnb2Z5cGpydmJleGxrZ2tkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDY2Nzc0NzIsImV4cCI6MjA2MjI1MzQ3Mn0.mD1CcnMmRvSxTai101tKX4DtXzNOumEOxhbrMPQqa4w'
);

const app = express();
app.use(cors());
app.use(express.json());

// Ruta raíz
app.get('/', (req, res) => {
  res.send('¡Bienvenido al backend de Green House!');
});

// Obtener propiedades
app.get('/propiedades', async (req, res) => {
  const { data, error } = await supabase.from('propiedades').select('*');
  if (error) return res.status(500).send(error.message);
  return res.json(data);
});

// Agregar propiedad
app.post('/propiedades', async (req, res) => {
  const { titulo, descripcion, precio, tipo, ubicacion, imagenes } = req.body;

  const { data, error } = await supabase.from('propiedades').insert([
    { titulo, descripcion, precio, tipo, ubicacion, imagenes }
  ]);

  if (error) return res.status(500).send(error.message);
  return res.status(201).json(data);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor corriendo en puerto ${PORT}`);
});
